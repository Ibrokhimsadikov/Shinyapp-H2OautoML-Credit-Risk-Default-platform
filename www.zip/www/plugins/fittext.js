// jQuery(".fit-head").fitText(1.2, { minFontSize: '26px', maxFontSize: '56px' });
jQuery(".fit-h1").fitText(1.2, { minFontSize: '32px', maxFontSize: '38px' });
jQuery(".fit-h2").fitText(1.2, { minFontSize: '18px', maxFontSize: '26px' });
jQuery(".fit-text").fitText(0.8, { minFontSize: '18px', maxFontSize: '24px' });
